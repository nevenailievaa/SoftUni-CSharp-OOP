﻿namespace NeedForSpeed;

public class CrossMotorcycle : Motorcycle
{
    //Constructor
    public CrossMotorcycle(int horsePower, double fuel) : base(horsePower, fuel) { }
}
