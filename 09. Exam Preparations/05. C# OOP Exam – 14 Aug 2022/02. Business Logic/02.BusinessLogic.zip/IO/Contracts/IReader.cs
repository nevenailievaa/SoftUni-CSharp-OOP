﻿namespace PlanetWars.IO.Contracts
{
    interface IReader
    {
        string ReadLine();
    }
}
