﻿namespace NeedForSpeed;

public class Motorcycle : Vehicle
{
    //Constructor
    public Motorcycle(int horsePower, double fuel) : base(horsePower, fuel) { }
}
