﻿namespace Restaurant;
public class Soup : Starter
{
    //Constructor
    public Soup(string name, decimal price, double grams) : base(name, price, grams){}
}
