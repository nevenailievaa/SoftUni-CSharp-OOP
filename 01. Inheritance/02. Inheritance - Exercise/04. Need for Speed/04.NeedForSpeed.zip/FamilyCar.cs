﻿namespace NeedForSpeed
{
    public class FamilyCar : Car
    {
        //Constructor
        public FamilyCar(int horsePower, double fuel) : base(horsePower, fuel) { }
    }
}
