﻿namespace PersonInfo;

public interface IPerson
{
    //Properties
    public string Name { get; set; }
    public int Age { get; set; }
}
