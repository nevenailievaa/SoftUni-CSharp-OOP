﻿namespace PlayersAndMonsters;

public class Elf : Hero
{
    //Constructor
    public Elf(string username, int level) : base(username, level) { }
}
