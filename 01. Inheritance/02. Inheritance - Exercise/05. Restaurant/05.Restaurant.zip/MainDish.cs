﻿namespace Restaurant;

public class MainDish : Food
{
    //Constructor
    public MainDish(string name, decimal price, double grams) : base(name, price, grams) { }
}
