﻿namespace PlayersAndMonsters;

public class DarkWizard : Wizard
{
    //Constructor
    public DarkWizard(string username, int level) : base(username, level) { }
}
