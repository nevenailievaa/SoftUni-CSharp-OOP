using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class AxeTests
    {
        [Test]
        public void AxeShouldInitializeWithCorrectValues()
        {
            //Arrange and Act
            Axe axe = new Axe(100, 100);

            //Assert
            Assert.AreEqual(100, axe.DurabilityPoints);
            Assert.AreEqual(100, axe.AttackPoints);
        }

        [Test]
        public void AttackMethodShouldDecreaseDurabilityPoints()
        {
            //Arrange
            Axe axe = new Axe(100, 10);
            Dummy target = new Dummy(10, 10);

            //Act
            axe.Attack(target);

            //Assert
            Assert.AreEqual(9, axe.DurabilityPoints);
        }

        [Test]
        public void AttackMethodShouldThrowAnExceptionIfDurabilityIsZero()
        {
            //Arrange
            Axe axe = new Axe(10, 10);
            Dummy target = new Dummy(100, 100);

            //Act
            for (int i = 1; i <= 10; i++)
            {
                axe.Attack(target);
            }

            //Assert
            Assert.Throws<InvalidOperationException>(() => axe.Attack(target), "Axe is broken.");
        }
    }
}