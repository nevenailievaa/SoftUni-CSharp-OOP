﻿namespace PlayersAndMonsters;

public class BladeKnight : Knight
{
    //Constructor
    public BladeKnight(string username, int level) : base(username, level) {}
}
