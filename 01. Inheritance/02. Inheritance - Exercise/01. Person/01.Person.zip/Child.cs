﻿namespace Person;

public class Child : Person
{
    //Constructor
    public Child(string name, int age) : base(name, age){}


}
