﻿namespace Restaurant;

public class ColdBeverage : Beverage
{
    //Constructor
    public ColdBeverage(string name, decimal price, double mililiters) : base(name, price, mililiters) {}
}
