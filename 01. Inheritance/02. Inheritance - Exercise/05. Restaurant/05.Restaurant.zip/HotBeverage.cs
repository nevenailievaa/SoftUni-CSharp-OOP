﻿namespace Restaurant;

public class HotBeverage : Beverage
{
    //Constructor
    public HotBeverage(string name, decimal price, double mililiters) : base(name, price, mililiters) {}
}
