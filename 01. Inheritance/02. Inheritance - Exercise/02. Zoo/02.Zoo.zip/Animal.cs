﻿namespace Zoo;

public class Animal
{
    //Constructor
    public Animal(string name)
    {
        Name = name;
    }

    //Property
    public string Name { get; set; }
}
