﻿namespace PlayersAndMonsters;

public class Knight : Hero
{
    //Constructor
    public Knight(string username, int level) : base(username, level) {}
}
