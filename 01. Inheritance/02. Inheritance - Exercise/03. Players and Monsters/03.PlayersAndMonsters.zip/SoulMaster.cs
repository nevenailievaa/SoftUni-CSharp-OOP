﻿namespace PlayersAndMonsters;

public class SoulMaster : Wizard
{
    //Constructor
    public SoulMaster(string username, int level) : base(username, level) {}
}
