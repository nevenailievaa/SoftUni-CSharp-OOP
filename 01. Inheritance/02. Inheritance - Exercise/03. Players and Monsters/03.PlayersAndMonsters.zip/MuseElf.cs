﻿namespace PlayersAndMonsters;

public class MuseElf : Elf
{
    //Constructor
    public MuseElf(string username, int level) : base(username, level) { }
}
